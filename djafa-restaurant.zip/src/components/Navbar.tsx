import { useState, useEffect } from "react";
import { Menu, X, Globe } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [lang, setLang] = useState<"en" | "ar">("en");

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const toggleLang = () => setLang(lang === "en" ? "ar" : "en");

  const navLinks = [
    { name: lang === "en" ? "Our Story" : "قصتنا", href: "#story" },
    { name: lang === "en" ? "Menu" : "القائمة", href: "#menu" },
    { name: lang === "en" ? "Atmosphere" : "الأجواء", href: "#atmosphere" },
    { name: lang === "en" ? "Contact" : "تواصل معنا", href: "#contact" },
  ];

  return (
    <nav
      className={`fixed w-full z-50 transition-all duration-300 ${isScrolled ? "bg-djafa-black/90 backdrop-blur-md py-4 shadow-lg shadow-black/50" : "bg-transparent py-6"}`}
    >
      <div className="max-w-7xl mx-auto px-6 md:px-12 flex justify-between items-center">
        <a href="#" className="flex flex-col items-center group">
          <span className="font-serif text-2xl md:text-3xl font-bold text-djafa-yellow tracking-wider group-hover:text-white transition-colors">
            Djafa
          </span>
          <span className="font-serif text-sm text-white tracking-widest">
            الضيافة
          </span>
        </a>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center space-x-8">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className="text-sm font-medium text-gray-300 hover:text-djafa-yellow transition-colors uppercase tracking-wider"
            >
              {link.name}
            </a>
          ))}
          <button
            onClick={toggleLang}
            className="flex items-center space-x-2 text-gray-300 hover:text-white transition-colors"
          >
            <Globe size={18} />
            <span className="text-sm font-medium uppercase">
              {lang === "en" ? "AR" : "EN"}
            </span>
          </button>
        </div>

        {/* Mobile Toggle */}
        <button
          className="md:hidden text-white"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      {/* Mobile Nav */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-full left-0 w-full bg-djafa-charcoal border-t border-white/10 py-6 px-6 flex flex-col space-y-4 md:hidden"
          >
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={() => setIsMobileMenuOpen(false)}
                className="text-lg font-medium text-gray-300 hover:text-djafa-yellow transition-colors"
              >
                {link.name}
              </a>
            ))}
            <button
              onClick={toggleLang}
              className="flex items-center space-x-2 text-gray-300 hover:text-white transition-colors pt-4 border-t border-white/10"
            >
              <Globe size={20} />
              <span className="text-lg font-medium">
                {lang === "en" ? "العربية" : "English"}
              </span>
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
