import { motion } from "motion/react";

export default function Story() {
  return (
    <section id="story" className="py-24 md:py-32 bg-djafa-black relative">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Text Content */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8 }}
            className="order-2 lg:order-1"
          >
            <div className="flex items-center gap-4 mb-6">
              <div className="h-[1px] w-12 bg-djafa-yellow"></div>
              <span className="text-djafa-yellow uppercase tracking-widest text-sm font-semibold">
                Our Story
              </span>
            </div>
            <h2 className="text-4xl md:text-5xl font-serif font-bold mb-8 leading-tight">
              A Legacy of{" "}
              <span className="text-djafa-yellow italic">Flavor</span> &
              Tradition
            </h2>
            <p className="text-gray-400 text-lg leading-relaxed mb-6 font-light">
              At Djafa, we believe that true hospitality is tasted before it is
              felt. Born from a passion for authentic Middle Eastern cuisine and
              modern culinary excellence, our restaurant offers a dining
              experience that bridges tradition with contemporary luxury.
            </p>
            <p className="text-gray-400 text-lg leading-relaxed mb-10 font-light">
              Every dish is crafted with the finest ingredients, a touch of
              heritage, and a commitment to perfection. Welcome to our
              table—where every meal is a celebration.
            </p>

            <div className="flex items-center gap-6">
              <div className="text-center">
                <span className="block text-3xl font-serif text-white">
                  15+
                </span>
                <span className="text-xs text-gray-500 uppercase tracking-wider">
                  Years Exp.
                </span>
              </div>
              <div className="w-[1px] h-10 bg-white/10"></div>
              <div className="text-center">
                <span className="block text-3xl font-serif text-white">
                  100%
                </span>
                <span className="text-xs text-gray-500 uppercase tracking-wider">
                  Fresh
                </span>
              </div>
            </div>
          </motion.div>

          {/* Image */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8 }}
            className="order-1 lg:order-2 relative"
          >
            <div className="relative rounded-2xl overflow-hidden aspect-[4/5] lg:aspect-square">
              <div className="absolute inset-0 bg-djafa-yellow/10 mix-blend-overlay z-10"></div>
              <img
                src="https://images.unsplash.com/photo-1555396273-367ea4eb4db5?q=80&w=2874&auto=format&fit=crop"
                alt="Djafa Restaurant Interior"
                className="object-cover w-full h-full hover:scale-105 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
            </div>
            {/* Decorative element */}
            <div className="absolute -bottom-6 -left-6 w-32 h-32 border-l-2 border-b-2 border-djafa-yellow rounded-bl-3xl -z-10"></div>
            <div className="absolute -top-6 -right-6 w-32 h-32 border-r-2 border-t-2 border-djafa-red rounded-tr-3xl -z-10"></div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
