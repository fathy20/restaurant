import { motion } from "motion/react";

const dishes = [
  {
    id: 1,
    name: "Signature Grilled Chicken",
    arName: "دجاج مشوي على الفحم",
    desc: "Marinated for 24 hours in our secret blend of spices, slow-grilled to perfection.",
    price: "$24",
    img: "https://images.unsplash.com/photo-1598514982205-f36b96d1e8dd?q=80&w=2940&auto=format&fit=crop",
  },
  {
    id: 2,
    name: "Royal Mixed Grill",
    arName: "مشاوي مشكلة ملكية",
    desc: "A premium selection of lamb chops, shish tawook, and kofta with garlic sauce.",
    price: "$42",
    img: "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?q=80&w=2787&auto=format&fit=crop",
  },
  {
    id: 3,
    name: "Truffle Hummus",
    arName: "حمص بالكمأة",
    desc: "Creamy traditional hummus elevated with black truffle oil and pine nuts.",
    price: "$16",
    img: "https://images.unsplash.com/photo-1633436374961-09b92742047b?q=80&w=2865&auto=format&fit=crop",
  },
  {
    id: 4,
    name: "Saffron Rice & Lamb",
    arName: "مجبوس لحم بالزعفران",
    desc: "Tender slow-cooked lamb served over fragrant saffron-infused basmati rice.",
    price: "$38",
    img: "https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?q=80&w=2813&auto=format&fit=crop",
  },
];

export default function Menu() {
  return (
    <section
      id="menu"
      className="py-24 bg-djafa-charcoal relative border-y border-white/5"
    >
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <span className="text-djafa-yellow uppercase tracking-widest text-sm font-semibold mb-4 block">
              Culinary Excellence
            </span>
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-white mb-4">
              Featured Dishes
            </h2>
            <p className="text-gray-400 max-w-2xl mx-auto font-light">
              A curated selection of our most beloved creations, blending
              premium ingredients with masterful technique.
            </p>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {dishes.map((dish, index) => (
            <motion.div
              key={dish.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="glass-card rounded-[16px] overflow-hidden group flex flex-col sm:flex-row"
            >
              <div className="sm:w-2/5 h-64 sm:h-auto overflow-hidden relative">
                <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors z-10"></div>
                <img
                  src={dish.img}
                  alt={dish.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="p-6 sm:w-3/5 flex flex-col justify-center relative">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h3 className="text-xl font-serif font-semibold text-white group-hover:text-djafa-yellow transition-colors">
                      {dish.name}
                    </h3>
                    <span className="text-sm text-gray-500 font-serif">
                      {dish.arName}
                    </span>
                  </div>
                  <span className="text-djafa-yellow font-semibold text-lg">
                    {dish.price}
                  </span>
                </div>
                <p className="text-gray-400 text-sm leading-relaxed mt-4 font-light">
                  {dish.desc}
                </p>

                <div className="mt-6">
                  <button className="text-xs uppercase tracking-wider font-semibold text-white border-b border-djafa-yellow pb-1 hover:text-djafa-yellow transition-colors">
                    Order Now
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="text-center mt-16">
          <a
            href="#full-menu"
            className="inline-block px-8 py-4 border border-white/20 rounded-[12px] text-white hover:bg-white hover:text-djafa-black transition-all duration-300"
          >
            View Full Menu
          </a>
        </div>
      </div>
    </section>
  );
}
