import { motion } from "motion/react";

export default function Hero() {
  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div
        className="absolute inset-0 z-0"
        style={{
          backgroundImage:
            'url("https://images.unsplash.com/photo-1514933651103-005eec06c04b?q=80&w=2874&auto=format&fit=crop")',
          backgroundPosition: "center",
          backgroundSize: "cover",
        }}
      >
        {/* Dark Overlay for readability */}
        <div className="absolute inset-0 bg-gradient-to-b from-djafa-black/80 via-djafa-black/60 to-djafa-black/90"></div>
      </div>

      <div className="relative z-10 text-center px-6 max-w-4xl mx-auto mt-20">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          <h2 className="text-djafa-yellow font-serif text-2xl md:text-3xl mb-4 tracking-widest">
            تجربة الضيافة بطعم مختلف
          </h2>
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-serif font-bold text-white mb-8 leading-tight">
            Djafa <br />
            <span className="text-3xl md:text-5xl font-light italic text-gray-300">
              The Taste of Hospitality
            </span>
          </h1>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-12">
            <a
              href="#order"
              className="w-full sm:w-auto px-8 py-4 bg-djafa-yellow text-djafa-black font-semibold rounded-[12px] hover:bg-djafa-red hover:text-white transition-all duration-300 shadow-[0_0_20px_rgba(234,179,8,0.3)] hover:shadow-[0_0_20px_rgba(127,29,29,0.5)] text-lg"
            >
              Order Now
            </a>
            <a
              href="#menu"
              className="w-full sm:w-auto px-8 py-4 bg-transparent border border-white/30 text-white font-medium rounded-[12px] hover:bg-white hover:text-djafa-black transition-all duration-300 text-lg glass-card"
            >
              View Menu
            </a>
          </div>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        className="absolute bottom-10 left-1/2 -translate-x-1/2 text-white/50 flex flex-col items-center"
        animate={{ y: [0, 10, 0] }}
        transition={{ repeat: Infinity, duration: 2 }}
      >
        <span className="text-xs uppercase tracking-widest mb-2 font-mono">
          Scroll
        </span>
        <div className="w-[1px] h-12 bg-gradient-to-b from-white/50 to-transparent"></div>
      </motion.div>
    </section>
  );
}
