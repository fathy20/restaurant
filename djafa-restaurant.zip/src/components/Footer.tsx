import {
  MapPin,
  Phone,
  Clock,
  Instagram,
  Facebook,
  MessageCircle,
} from "lucide-react";

export default function Footer() {
  return (
    <footer
      id="contact"
      className="bg-[#050505] pt-20 pb-10 border-t border-white/5"
    >
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 mb-16">
          {/* Contact Info */}
          <div>
            <h2 className="text-3xl font-serif font-bold text-white mb-8">
              Visit Us
            </h2>

            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <MapPin className="text-djafa-yellow shrink-0 mt-1" size={24} />
                <div>
                  <h4 className="text-white font-medium mb-1">Location</h4>
                  <p className="text-gray-400 font-light">
                    123 Luxury Avenue, Culinary District
                    <br />
                    City, State 12345
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <Phone className="text-djafa-yellow shrink-0 mt-1" size={24} />
                <div>
                  <h4 className="text-white font-medium mb-1">Reservations</h4>
                  <p className="text-gray-400 font-light">+1 (555) 123-4567</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <Clock className="text-djafa-yellow shrink-0 mt-1" size={24} />
                <div>
                  <h4 className="text-white font-medium mb-1">Hours</h4>
                  <p className="text-gray-400 font-light">
                    Mon - Thu: 11:00 AM - 11:00 PM
                    <br />
                    Fri - Sun: 11:00 AM - 1:00 AM
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-10">
              <a
                href="https://wa.me/15551234567"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3 bg-[#25D366] text-white font-medium rounded-[12px] hover:bg-[#1DA851] transition-colors"
              >
                <MessageCircle size={20} />
                Order via WhatsApp
              </a>
            </div>
          </div>

          {/* Map */}
          <div className="h-80 lg:h-full min-h-[300px] rounded-2xl overflow-hidden border border-white/10 grayscale hover:grayscale-0 transition-all duration-500">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3022.1422937950147!2d-73.98731968459391!3d40.75889497932681!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25855c6480299%3A0x55194ec5a1ae072e!2sTimes%20Square!5e0!3m2!1sen!2sus!4v1621530000000!5m2!1sen!2sus"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen={false}
              loading="lazy"
            ></iframe>
          </div>
        </div>

        {/* Bottom Footer */}
        <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex flex-col items-center md:items-start">
            <span className="font-serif text-xl font-bold text-white tracking-wider">
              Djafa
            </span>
            <span className="text-xs text-gray-500 mt-1">
              © {new Date().getFullYear()} Djafa Restaurant. All rights
              reserved.
            </span>
          </div>

          <div className="flex items-center gap-4">
            <a
              href="#"
              className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-gray-400 hover:bg-djafa-yellow hover:text-djafa-black transition-all"
            >
              <Instagram size={18} />
            </a>
            <a
              href="#"
              className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-gray-400 hover:bg-djafa-yellow hover:text-djafa-black transition-all"
            >
              <Facebook size={18} />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
